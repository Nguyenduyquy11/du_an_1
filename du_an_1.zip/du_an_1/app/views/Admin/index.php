<?php
   
    include "layout/header.php";
   include "../../controllers/AdminController/admin.php";
    include "layout/home.php";
    include "layout/footer.php";
?>