<?php
   
   include "controllers/ClientController/client.php";
    //include "views/Client/layout/header.php";
    //include "views/Client/layout/home.php";
    //include "views/Client/layout/footer.php";
    ?>